package IT_Academy.HW_11;

public class Calculator {
    public static void main(String[] args) {
        new BaseForm();
    }
}
