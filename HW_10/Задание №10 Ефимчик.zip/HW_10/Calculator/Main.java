package IT_Academy.HW_10.Calculator;

public class Main {
    public static void main(String[] args)
    {
        new Calculator();
    }
}
