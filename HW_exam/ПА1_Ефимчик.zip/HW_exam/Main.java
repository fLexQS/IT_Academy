package IT_Academy.HW_exam;

import java.io.FileNotFoundException;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        new BaseWindow();
    }
}
