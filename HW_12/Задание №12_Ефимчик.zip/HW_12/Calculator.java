package IT_Academy.HW_12;

public class Calculator {
    public static void main(String[] args) {
        new BaseForm();
    }
}
